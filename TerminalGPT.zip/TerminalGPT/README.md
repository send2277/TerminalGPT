# TerminaGPT
Translate your requests into linux terminal prompt

Before you can run the installer file, you need to make it executable. To do this, open a terminal window and navigate to the directory where the installer file is located. Then, use the following command:

```
chmod +x installer.sh
```
This will give the installer file executable permissions.

To run the installer file, simply type the following command in the terminal:
```
./installer.sh
```
This will start the installation process.
After that open terminal and type ``` gpt ``` and describe what do you need to do.
Thats it!
